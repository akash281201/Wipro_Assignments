package com.example.ordermanagement.model;

public class Order {
    private int orderId;
    private String items;
    private Boolean status;

    // Constructors, Getters, and Setters

    public Order(int orderId, String items, Boolean status) {
        this.orderId = orderId;
        this.items = items;
        this.status = status;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getItems() {
        return items;
    }

    public void setItems(String items) {
        this.items = items;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }
}