package com.example.ordermanagement.dao;

import com.example.ordermanagement.model.Order;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Repository
public class OrderDAO {
    private Map<Integer, Order> orderMap = new HashMap<>();

    public OrderDAO() {
        // Initializing with some sample data
        orderMap.put(1, new Order(1, "Item1", true));
        orderMap.put(2, new Order(2, "Item2", false));
        orderMap.put(3, new Order(3, "Item3", true));
    }

    public Collection<Order> getOrdersList() {
        return orderMap.values();
    }

    public Collection<Order> getCancelledOrders() {
        return orderMap.values().stream()
                       .filter(order -> !order.getStatus())
                       .collect(Collectors.toList());
    }
}