package com.example.ordermanagement.controller;

import com.example.ordermanagement.dao.OrderDAO;
import com.example.ordermanagement.model.Order;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderDAO orderDAO;

    public OrderController(OrderDAO orderDAO) {
        this.orderDAO = orderDAO;
    }

    @GetMapping("/list")
    public Collection<Order> getOrdersList() {
        return orderDAO.getOrdersList();
    }

    @GetMapping("/cancelled")
    public Collection<Order> getCancelledOrdersList() {
        return orderDAO.getCancelledOrders();
    }
}