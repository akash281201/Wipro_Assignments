package com.example.productionmanagement.controller;

import com.example.productionmanagement.client.OrderClient;
import com.example.productionmanagement.model.Order;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@RestController
@RequestMapping("/production")
public class ProductionController {

    private final OrderClient orderClient;

    public ProductionController(OrderClient orderClient) {
        this.orderClient = orderClient;
    }

    @GetMapping("/orders")
    public Collection<Order> getOrdersList() {
        return orderClient.getOrders();
    }

    @GetMapping("/cancelled")
    public Collection<Order> getCancelledOrdersList() {
        return orderClient.getCancelledOrders();
    }
}