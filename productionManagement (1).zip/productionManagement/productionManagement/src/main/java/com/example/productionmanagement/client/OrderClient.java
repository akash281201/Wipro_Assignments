package com.example.productionmanagement.client;

import com.example.productionmanagement.model.Order;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Collection;

@FeignClient(name = "order-service", url = "http://localhost:8081/orders")
public interface OrderClient {

    @GetMapping("/list")
    Collection<Order> getOrders();

    @GetMapping("/cancelled")
    Collection<Order> getCancelledOrders();
}